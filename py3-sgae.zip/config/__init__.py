




def get_conf():
    return {'device': 'cuda'}